﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (label2.Text != "") {
                label2.Text += "+";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text += (int.Parse(button1.Text)).ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text += (int.Parse(button2.Text)).ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text += (int.Parse(button3.Text)).ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text += (int.Parse(button4.Text)).ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text += (int.Parse(button5.Text)).ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text += (int.Parse(button6.Text)).ToString();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text += (int.Parse(button7.Text)).ToString();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text += (int.Parse(button8.Text)).ToString();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text += (int.Parse(button9.Text)).ToString();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text += (int.Parse(button10.Text)).ToString();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (label1.Text == "0")
            {
                label1.Text = "";
                label2.Text = "0.";
            }
            else {
                label2.Text += button11.Text;
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            string express = (label2.Text);
            double answer=0.0;
            express = express.Replace("x", "*");
            express = express.Replace("÷", "/");
            if (express.Contains('/'))
            {
                answer = (double)dt.Compute(express, "");
                if (((answer).ToString()).Length > 7)
                {
                    answer = Math.Round(answer, 3);
                }
            }
            else if (express.Contains('.'))
            {
                decimal dec = (decimal)dt.Compute(express, "");
                answer = (double)dec;
            }
            else
            {
                answer = (int)dt.Compute(express, "");
            }
            label3.Text = label2.Text+"= "+((answer).ToString());
            label2.Text = "";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (((label2.Text).Length) > 0)
            {
                label2.Text = (label2.Text).Remove((label2.Text).Length - 1);
                label1.Text = "0";
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            label2.Text = "";
            label1.Text = "0";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (label2.Text != "")
            {
                label2.Text += "÷";
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (label2.Text != "")
            {
                label2.Text += "x";
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (label2.Text != "")
            {
                label2.Text += "-";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}